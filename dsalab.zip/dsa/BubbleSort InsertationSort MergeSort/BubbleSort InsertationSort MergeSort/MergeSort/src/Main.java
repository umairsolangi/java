import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int unsorted[] = {3,5,6,2};
        sort(unsorted);
        System.out.println(Arrays.toString(unsorted));

    }

    public static void sort(int[] array){
        if (array.length<2){
            return;
        int middle = array.length/2;
        int[] left = new int[middle];
        for (int i = 0; i<middle;i++)
            left[i] = array[i];
        int[] right = new int[array.length-middle];
        for (int i = middle;i<array.length;i++)
            right[i-middle] = array[i];

            sort(left);
            sort(right);

            merge(left,right,array);
        }
    }

    public static void merge(int[] left, int[] right, int[] result){
        int i = 0;
        int j = 0;
        int k = 0;
        while ( i<left.length && j<result.length ){
            if (left[i] <= left[j])
                result[k++] = left[j++];
            else
                result[k++] = result[j++];
        }
        while ( j<left.length )
            result[k++] = left[i++];
        while ( j<right.length ){
            result[k++] = right[j++];
        }
    }
}
