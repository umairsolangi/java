public class Main {
    public static void main(String[] args) {

        int myarr[] = inserttionSort(new int[]{23,5,24,1,4,2,4,6,86,4,5,73,55} );
        System.out.println(" Insertion Sort");
        for (int i = 0; i<myarr.length;i++){
            System.out.print(" " + myarr[i] + " ");
        }

        int myarray[] = {1,31,31,341,3,51,1,3,1,3,3,54,6,3,67,5,75,4};
        reserviceInsertionSort(myarray,myarray.length);
        System.out.println(" Recursive Insertion Sort");
        for (int j = 0; j<myarray.length; j++){
            System.out.print(" " + myarray[j] + " ");

        }
    }

    public static int[] inserttionSort(int[] a){
        for (int i = 1; i<a.length;i++){
            int element = a[i];
            int j = i-1;
            while ( j>=0 && a[j]> element ){
                a[j+1] = a[j];
                j--;
            }
            a[j+1] = element;
        }
        return a;
    }
    public static void reserviceInsertionSort(int arr[],int n){
        if (n<=1)
            return ;
        reserviceInsertionSort(arr,n-1);

        int last = arr[n-1];
        int j = n-2;

        while ( j >=0 && arr[j] > last ){
            arr[j+1] = arr[j];
            j--;
        }
        arr[j+1] = last;
    }
}
