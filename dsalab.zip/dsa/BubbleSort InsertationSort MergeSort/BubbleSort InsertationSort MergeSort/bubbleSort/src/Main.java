import java.util.Arrays;

public class Main {
   public static void main(String args[])
    {
        int a= 255;
        int b= 25;
        a=a+b;
        b=a-b;
        a=a-b;
        System.out.println(a);
        System.out.println(b);
    }
}

