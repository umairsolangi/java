import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        int[] array = {1, 2, 3, 6, 5, 6, 7, 8, 9, 10, 11,12,13,14,15};
        int[] sortingArrayUsingSelectionSort = {32,43,223,645,6,211234,67,224,61,136,1,13,6,13};
        int[] sortingArrayUsingResursiveSelectionSort = {32,43,223,645,6,211234,67,224,61,136,1,13,6,13};
        int[] sel = selectionSort(sortingArrayUsingSelectionSort);
        for (int k = 0; k<sortingArrayUsingSelectionSort.length;k++){
            System.out.println("Using Selection Sort" + sel[k]);
        }


        int[] Reservesel = selectionSort(sortingArrayUsingSelectionSort);
        for (int l = 0; l<sortingArrayUsingSelectionSort.length;l++){
            System.out.println("Using Reserve Selection Sort" + Reservesel[l]);
        }

        int index2 = JumpSearch(array, 2);
        //int index1 = ternarySearch(array,8,0,array.length-1);
        if (index2 != -1)
            System.out.println("Value Found at index " + index2);
        else
            System.out.println("Value Not Found");


    }


    public static int ternarySearch(int[] array, int target, int left, int right) {
        if (left > right)
            return -1;

        int partitation = (right - left) / 3;
        int mid1 = left + partitation;
        int mid2 = right - partitation;

        if (array[mid1] == target)
            return mid1;

        if (array[mid2] == target)
            return mid2;

        if (target < array[mid1])
            return ternarySearch(array, target, left, mid1 - 1);

        if (target > array[mid2])
            return ternarySearch(array, target, mid2 + 1, right);
        else
            return ternarySearch(array, target, mid1 + 1, mid2 - 1);


    }


    public static int JumpSearch(int[] array, int target) {
        int blockSize = (int) Math.sqrt(array.length);
        int start = 0;
        int next = blockSize;

        while ( start < array.length && array[next - 1] < target ) {
            start = next;

            next += blockSize;
            if (next > array.length) {
                next = array.length;
            }
        }

        for (int i = start; i < next; i++) {
            if (array[i] == target) {
                return i;
            }
        }
        return -1;
    }

    public static int[] selectionSort(int a[]) {
        int minimum;
        for (int i = 0; i < a.length; i++) {
            minimum = i;
            for (int j = i; j < a.length; j++) {
                if (a[j] < a[minimum])
                minimum = j;
            }
            int temp = a[i];
            a[i] = a[minimum];
            a[minimum] = temp;
        }
        return a;
    }

    public static void recursiveSelectionSort(int a[], int i, int j){
        if (i ==a.length)
            System.out.println(Arrays.toString(a));
        else if(j==a.length){
            recursiveSelectionSort(a,i+1,j+2);
        }
        else{
            if (a[i] > a[j]){
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }

            recursiveSelectionSort(a,i,j+1);
        }
    }
}
