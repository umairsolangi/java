
interface PetCharacteristics {
    void infoOfPet();
    void petSound();
}

public abstract class Pet implements PetCharacteristics {
    protected String petName;
    protected int petAge;
    protected String petColor;
    protected String petBreed;
    protected String typeOfPet;

    public Pet(String name, int age, String color, String breed) {
        this.petName = name;
        this.petAge = age;
        this.petColor = color;
        this.petBreed = breed;
        this.typeOfPet = "Unknown";
    }

    public int getPetAge() {
        return petAge;
    }

    public String getPetBreed() {
        return petBreed;
    }

    public String getPetName() {
        return petName;
    }

    public String getPetColor() {
        return petColor;
    }

    public String getTypeOfPet() {
        return typeOfPet;
    }
}
