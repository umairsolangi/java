// Create a mini project using Java language to make an Online Pet shop using all the concepts of
// OOP including interfaces where needed.

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("\t\t_____WELCOME TO OUR ONLINE PET STORE______\n");

        String name, color, breed;
        int age, flag = 0;

        do {
            try{
                System.out.println("We have the following pets available:\n\n1)Cat\n2)Dog\n3)Parrot\n4)GoldFish\n");
                System.out.println("Which one would you like to get? ");
                int op = Integer.valueOf(scan.nextLine());

                switch (op) {
                    case 1:
                        System.out.println("You've chosen to get a Cat!");

                        System.out.println("Which breed of cat do you want? ");
                        breed = scan.nextLine();

                        System.out.println("Which color of cat do you want? ");
                        color = scan.nextLine();

                        System.out.println("What should be the max age of cat? ");
                        age = Integer.valueOf(scan.nextLine());

                        System.out.println("The type of Cat you wish to want is available!");

                        System.out.println("What do you want to name it? ");
                        name = scan.nextLine();

                        Cat pet1 = new Cat(name, age, color, breed);
                        pet1.infoOfPet();
                        break;

                    case 2:
                        System.out.println("You've chosen to get a Dog!");

                        System.out.println("Which breed of dog do you want? ");
                        breed = scan.nextLine();

                        System.out.println("Which color of dog do you want? ");
                        color = scan.nextLine();

                        System.out.println("What should be the max age of dog? ");
                        age = Integer.valueOf(scan.nextLine());

                        System.out.println("The type of dog you wish to want is available!");

                        System.out.println("What do you want to name it? ");
                        name = scan.nextLine();

                        Dog pet2 = new Dog(name, age, color, breed);
                        pet2.infoOfPet();
                        break;

                    case 3:
                        System.out.println("You've chosen to get a Parrot!");

                        System.out.println("Which breed of parrot do you want? ");
                        breed = scan.nextLine();

                        System.out.println("Which color of parrot do you want? ");
                        color = scan.nextLine();

                        System.out.println("What should be the max age of parrot? ");
                        age = Integer.valueOf(scan.nextLine());

                        System.out.println("The type of parrot you wish to want is available!");

                        System.out.println("What do you want to name it? ");
                        name = scan.nextLine();

                        Parrot pet3 = new Parrot(name, age, color, breed);
                        pet3.infoOfPet();
                        break;

                    case 4:
                        System.out.println("You've chosen to get a Goldfish!");

                        System.out.println("Which breed of goldfish do you want? ");
                        breed = scan.nextLine();

                        System.out.println("Which color of goldfish do you want? ");
                        color = scan.nextLine();

                        System.out.println("What should be the max age of goldfish? ");
                        age = Integer.valueOf(scan.nextLine());

                        System.out.println("The type of goldfish you wish to want is available!");

                        System.out.println("What do you want to name it? ");
                        name = scan.nextLine();

                        GoldFish pet4 = new GoldFish(name, age, color, breed);
                        pet4.infoOfPet();
                        break;

                }

            }catch (Exception e) {
                System.out.println(e.getMessage());
            }

            System.out.println("Do you want to browse the store again? (1 for yes, 0 for no) ");
            flag = Integer.valueOf(scan.nextLine());

        } while(flag == 1);

        System.out.println("Thank you for visiting our store!");
    }
}
