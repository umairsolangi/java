public class Dog extends Pet {
    public Dog(String name, int age, String color, String breed) {
        super(name, age, color, breed);
        this.typeOfPet = "Dog";
    }

    @Override
    public void infoOfPet() {
        System.out.printf("The pet %s of breed %s has the name %s, is %d years old.\n", typeOfPet, petBreed, petName, petAge);
    }

    @Override
    public void petSound() {
        System.out.println("Barkkk!");
    }
}
