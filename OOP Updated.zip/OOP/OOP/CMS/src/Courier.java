public class Courier {

    protected String Name;
    protected int Age;
    protected String PackageName;
    protected String PickupAddress;
    protected String DeliverAddress;
    protected String DeliverThrough;

    public String getName() {
        return Name;
    }

    public int getAge() {
        return Age;
    }

    public String getPackageName() {
        return PackageName;
    }

    public String getPickupAddress() {
        return PickupAddress;
    }

    public String getDeliverAddress() {
        return DeliverAddress;
    }

    public String getDeliverThrough() {
        return DeliverThrough;
    }

    public Courier(String name, int age, String packageName, String pickupAddress, String deliverAddress) {
        Name = name;
        Age = age;
        PackageName = packageName;
        PickupAddress = pickupAddress;
        DeliverAddress = deliverAddress;
    }
}
