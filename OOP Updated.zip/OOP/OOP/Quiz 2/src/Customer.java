public abstract class Customer extends Person {

    protected int balance;

    public Customer(String name, int age, int birthDate) {
        super(name, age, birthDate);
    }

    //public abstract void setBalance();
}
