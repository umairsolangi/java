// Undergraduate is passed when coursegrade is 70 or above

public class UnderGradStd extends Student{

    public UnderGradStd(String name, int age, int birthDate) {
        super(name, age, birthDate);
    }

    public void computeCourseGrade() {
        int totalMarks = 0;
        for(int i = 0; i<noOfTests; i++) {
            totalMarks += test[i];
        }

        // there were 3 tests.
        if((totalMarks/3) >= 70) {
            courseGrade = "Passed";
        } else {
            courseGrade = "failed";
        }
    }
}
