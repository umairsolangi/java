import java.util.Scanner;

public abstract class Student extends Person{
    protected String courseGrade;
    protected final int noOfTests = 3;
    protected int[] test;

    public Student(String name, int age, int birthDate) {
        super(name, age, birthDate);
        test = new int[noOfTests];
        this.courseGrade = "";
    }

    public void takeTestMarks() {
        Scanner scan = new Scanner(System.in);
        int marks;
        for(int i = 0; i<noOfTests; i++) {
            System.out.printf("Enter marks of test %d: ", i+1 );
            marks = Integer.valueOf(scan.nextLine());
            test[i] = marks;
        }
    }

    public abstract void computeCourseGrade();
}
