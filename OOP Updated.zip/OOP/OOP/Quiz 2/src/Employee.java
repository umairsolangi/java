public abstract class Employee extends Person {

    protected String designation;
    protected final double monthlyPayment = 50000;

    public Employee(String name, int age, String designation, int birthDate) {
        super(name, age, birthDate);
        this.designation = designation;
    }

    public String getDesignation() {
        return designation;
    }

    public abstract void calculateAndShowAnnualPayment();
}
