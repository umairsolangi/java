// Graduate student is passed if he gets 80 or above in course grade.

public class GradguateStd extends Student {

    public GradguateStd(String name, int age, int birthDate) {
        super(name, age, birthDate);
    }

    public void computeCourseGrade() {
        int totalMarks = 0;
        for(int i = 0; i<noOfTests; i++) {
            totalMarks += test[i];
        }

        // there were 3 tests.
        if((totalMarks/3) >= 80) {
            courseGrade = "Passed";
        } else {
            courseGrade = "failed";
        }
    }
}
