public class Walken extends Customer {

    public Walken(String name, int age, int birthDate) {
        super(name, age, birthDate);
        this.setBalance();
    }

    // default balance is 0.

    private void setBalance() {
        balance = 0;
    }
}
