public class Regular extends Customer {


    public Regular(String name, int age, int birthDate) {
        super(name, age, birthDate);
    }

    public void setBalance(int amount) {
        balance = amount;
    }
}
