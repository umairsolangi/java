public class Dog extends Pet {

    protected int Price = 8000;

    public int getPrice() {
        return Price;
    }

    public Dog(String color, int age, int quantity, int price,String name) {
        super(color, age, quantity,name);
        Price = price;
    }
}
