public class Caroot extends Pet{

    protected int Price = 20000;

    public int getPrice() {
        return Price;
    }

    public Caroot(String color, int age, int quantity, int price,String name) {
        super(color, age, quantity,name);
        Price = price;
    }
}
