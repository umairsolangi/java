import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("\t\t Well Come To Our Pet Shop\t\t");
        System.out.println("\t\t Everything you want\t\t ");

        String color;
        int quantity,age,total;

        System.out.println("Select Pets Category \n 01) Cat \n 02) Dog \n 03) Caroot");
        int op = Integer.valueOf(scan.nextLine());

        switch (op){
            case 1:
                int op2;
                System.out.println("Which cat you want to buy \n 01) African Cat \n 02) Jarman  \n  Cat 03) Pakistani Cat \n" );
                op2 = Integer.valueOf(scan.nextLine());
                switch (op2){
                    case 1:
                        System.out.println("So you want to buy African Cat \n");
                        System.out.println("You Selected African Cat to Buy \n Give us More Info about you Cat \n");

                        System.out.println("Enter Color of African Cat");
                        color = scan.nextLine();

                        System.out.println("Enter Age of African Cat");
                        age = Integer.valueOf(scan.nextLine());

                        System.out.println("Enter Quantity");
                        quantity = Integer.valueOf(scan.nextLine());
                        Cat cat = new Cat(color,age,quantity,23000,"Africe Cat");
                      //  int quan = cat.getQuantity();
                     //   int price = cat.getPrice();
                     //   int totalBil = price*quan;
                     //   System.out.println("Your Total Bill is" + totalBil);
                        totalBill(cat);


                        break;
                    case 2:
                        System.out.println("So you want to buy Jerman Cat \n");
                        System.out.println("You Selected Jerman Cat to Buy \n Give us More Info about you Cat \n");

                        System.out.println("Enter Color of Jarman Cat");
                        color = scan.nextLine();

                        System.out.println("Enter Age of Jarman Cat");
                        age = Integer.valueOf(scan.nextLine());

                        System.out.println("Enter Quantity");
                        quantity = Integer.valueOf(scan.nextLine());
                        break;
                    case 3:
                        System.out.println("So You want to buy Pakistnai Cat");
                        System.out.println("You Selected Pakistani Cat to Buy \n Give us More Info about you Cat \n");

                        System.out.println("Enter Color of Pakistani Cat");
                        color = scan.nextLine();

                        System.out.println("Enter Age of Pakistani Cat");
                        age = Integer.valueOf(scan.nextLine());

                        System.out.println("Enter Quantity");
                        quantity = Integer.valueOf(scan.nextLine());

                        break;
                }
                break;
            case 2:
                System.out.println("Which Dog you want to buy \n 01) Jerman Dog 02) \n Indian Dog \n 03) Israili Dog \n");
                int op3;
                op3 = Integer.valueOf(scan.nextLine());
                switch (op3){
                    case 1:
                        System.out.println("So you want to buy African Dog");
                        System.out.println("You Selected Jerman Dog to Buy \n Give us More Info about you Dog \n");
                        break;
                    case 2:
                        System.out.println("So you want to buy Jerman Dog");
                        System.out.println("You Selected Indian Dog to Buy \n Give us More Info about you Dog \n");
                        break;
                    case 3:
                        System.out.println("So You want to buy Pakistnai Dog");
                        System.out.println("You Selected Israili Dog to Buy \n Give us More Info about you Dog \n");
                        break;
                }
                break;
            case 3:
                System.out.println("Which Paroot you want to buy \n 01) African Caroot 02) \n Chinese Paroot \n 03) Pakistni Paroot \n");
                int op4;
                op4 = Integer.valueOf(scan.nextLine());
                switch (op4){
                    case 1:
                        System.out.println("So you want to buy African Paroot");
                        System.out.println("You Selected African Paroot to Buy \n Give us More Info about you Paroot \n");
                        break;
                    case 2:
                        System.out.println("So you want to buy Jerman Paroot");
                        System.out.println("You Selected Chiniese Paroot to Buy \n Give us More Info about you Paroot \n");
                        break;
                    case 3:
                        System.out.println("So You want to buy Pakistnai Paroot");
                        System.out.println("You Selected Paroot to Buy \n Give us More Info about you Paroot \n");
                        break;
                }
                break;
        }
    }

    public static void totalBill(Pet total){
        int totalPrice = total.getPrice();
        int quant = total.getQuantity();
        int totalBill = totalPrice*quant;
        System.out.println(totalBill);
        System.out.printf("Congrats you buyed %d %s",total.getQuantity(),total.getName());
    }
}
