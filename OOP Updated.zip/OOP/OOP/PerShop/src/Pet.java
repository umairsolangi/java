public class Pet {
    protected String Name;
    protected String Color;
    protected int Age;
    protected int Quantity;
    protected int Price;

    public int getPrice() {
        return Price;
    }



    public Pet(String color, int age, int quantity, String name) {
        Color = color;
        Age = age;
        Quantity = quantity;
        Name = name;
    }
    public String getName() {
        return Name;
    }
    public String getColor() {
        return Color;
    }

    public int getAge() {
        return Age;
    }

    public int getQuantity() {
        return Quantity;
    }
}
