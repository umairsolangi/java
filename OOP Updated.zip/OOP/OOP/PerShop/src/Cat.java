public class Cat extends Pet{

    protected int Price = 10000;

    public Cat(String color, int age, int quantity, int price,String name) {
        super(color, age, quantity,name);
        Price = price;
    }

    public int getPrice() {
        return Price;
    }


}
