public abstract class Company extends Category {

    // Make company abstract and make an abstract function take input that watches and perfume needs to implement.


    // Like rolex, Ray-Ban.
    protected String company;
    // Each company like rolex has its characteristics like price, color, and model.
    protected String model;
    protected int price;
    protected int id;
    //protected String color;

    // Should add id so that we can look up to that specific items price.
    public Company(String category, String company, String model, int price, int id) {
        super(category);
        this.company = company;
        this.model = model;
        this.price = price;
        this.id = id;
        //this.color = color;
    }


}
