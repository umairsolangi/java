public class Product extends Company {

    // Here you can ask features for each specific product.
    // Each product has its specific features. Maybe I can write a description of the product.

    // Make input function and ask all input from user which you took in main.
    public Product(String category, String company, String model, int price, int id) {
        super(category, company, model, price, id);
    }

}
