public class Category {
    protected String category;

    public Category(String category) {
        this.category = category;
    }
}
