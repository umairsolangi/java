import java.util.ArrayList;

public class DataStored {
    public ArrayList<Watches> watches;
    public ArrayList<Perfumes> perfumes;
    public ArrayList<Shoes> shoes;
    public ArrayList<MobilePhones> mobilePhones;
    //public ArrayList<Headphones> headphones;
    public ArrayList<Product> otherProducts;

    public DataStored() {
        this.watches = new ArrayList<>();
        this.perfumes = new ArrayList<>();
        this.shoes = new ArrayList<>();
        this.mobilePhones = new ArrayList<>();
        //this.headphones = new ArrayList<>();
        this.otherProducts = new ArrayList<>();

    }

    public void addWatch(Watches watch) {
        this.watches.add(watch);
    }

    public void addPerfume(Perfumes perfume) {
        this.perfumes.add(perfume);
    }
    public void addShoes(Shoes shoes){
        this.shoes.add(shoes);
    }
    public void addMobilePhones(MobilePhones mobilePhones){
        this.mobilePhones.add(mobilePhones);
    }

    public void addOtherProduct(Product product) {
        this.otherProducts.add(product);
    }

    public Watches getWatch(int index) {
        return watches.get(index);
    }

    public Perfumes getPerfume(int index) {
        return perfumes.get(index);
    }
    public Shoes getShoes(int index){
        return shoes.get(index);
    }
    public MobilePhones getMobilePhones(int index){
        return mobilePhones.get(index);
    }

    public Product getOtherProduct(int index) {
        return otherProducts.get(index);
    }
}
