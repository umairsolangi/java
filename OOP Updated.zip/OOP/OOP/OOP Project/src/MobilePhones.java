public class MobilePhones extends Company{
    public MobilePhones(String category, String company, String model, int price, int id) {
        super(category, company, model, price, id);
    }
}
