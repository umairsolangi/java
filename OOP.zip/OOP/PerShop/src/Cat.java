public class Cat extends Pet{

    protected int Price = 10000;

    public int getPrice() {
        return Price;
    }

    public Cat(String color, int age, int quantity, int price) {
        super(color, age, quantity);
        Price = price;
    }
}
