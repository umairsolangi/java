public class Pet {
    protected String Color;
    protected int Age;
    protected int Quantity;

    public Pet(String color, int age, int quantity) {
        Color = color;
        Age = age;
        Quantity = quantity;
    }

    public String getColor() {
        return Color;
    }

    public int getAge() {
        return Age;
    }

    public int getQuantity() {
        return Quantity;
    }
}
