public class CourierBySea extends Courier{

    protected String ElectronicsFee = "33$";
    protected String FoodFee = "30$";
    protected String GeneralItemsFee = "25$";
    protected String otherItemFee = "20$";


    public String getElectronicsFee() {
        return ElectronicsFee;
    }

    public String getFoodFee() {
        return FoodFee;
    }

    public String getGeneralItemsFee() {
        return GeneralItemsFee;
    }

    public String getOtherItemFee() {
        return otherItemFee;
    }


    public CourierBySea(String name, int age, String packageName, String pickupAddress, String deliverAddress) {
        super(name, age, packageName, pickupAddress, deliverAddress);
        this.DeliverThrough = "By Sea";
    }
}
