public class CourierByLand extends Courier{
    protected String ElectronicsFee = "25$";
    protected String FoodFee = "27$";
    protected String GeneralItemsFee = "20$";
    protected String otherItemFee = "15$";

    public String getFoodFee() {
        return FoodFee;
    }

    public String getGeneralItemsFee() {
        return GeneralItemsFee;
    }

    public String getOtherItemFee() {
        return otherItemFee;
    }





    public CourierByLand(String name, int age, String packageName, String pickupAddress, String deliverAddress) {
        super(name, age, packageName, pickupAddress, deliverAddress);
         this.DeliverThrough = "By Land";
      }
    public String getElectronicsFee() {
        return ElectronicsFee;
    }
}
