import java.sql.SQLOutput;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Well Come to Our Courier Management System");
        System.out.println("\t\tWe are every where\t\t \n");

        String name,pickaddress,deliveryaddress,packagename;
        int age,flag = 0;
do{
    try{
        System.out.println("Select the Way: \n 01) Delivery Through Land (20$) \n 02) Delivery Through Sea (30$)");
        int op = Integer.valueOf(scan.nextLine());
        ValidateOption(op);


        switch (op) {
            case 1:
                System.out.println("You've Selected the option to go by Land \n");
                int op2;
                System.out.println("Category \n Select Option \n 01) Electronics \n 02) Food \n 03) General Items \n 04) Other");
                op2 = Integer.valueOf(scan.nextLine());
                switch (op2){
                    case 1:
                        System.out.println("So You Want to Deliver Electronics Items");

                    System.out.println("Enter Your Good Name");
                    name = scan.nextLine();
                    ValidateName(name);

                    System.out.println("Enter you Age");
                    age = Integer.valueOf(scan.nextLine());
                    ValidateAge(age);

                    System.out.println("Enter Package Name");
                    packagename = scan.nextLine();

                    System.out.println("Enter Pickup City");
                    pickaddress = scan.nextLine();

                    System.out.println("Enter Delivery City");
                    deliveryaddress = scan.nextLine();

                    CourierByLand courierByLand = new CourierByLand(name,age,packagename,pickaddress,deliveryaddress);
                    ShowResult(courierByLand);
                        System.out.printf("You Bill is %s", courierByLand.getElectronicsFee());
                        break;
                    case 2:
                        System.out.println("So You Want to Deliver Food Items");

                        System.out.println("Enter Your Good Name");
                        name = scan.nextLine();
                        ValidateName(name);

                        System.out.println("Enter you Age");
                        age = Integer.valueOf(scan.nextLine());
                        ValidateAge(age);

                        System.out.println("Enter Package Name");
                        packagename = scan.nextLine();

                        System.out.println("Enter Pickup City");
                        pickaddress = scan.nextLine();

                        System.out.println("Enter Delivery City");
                        deliveryaddress = scan.nextLine();

                        CourierByLand courierByLand2 = new CourierByLand(name,age,packagename,pickaddress,deliveryaddress);
                        ShowResult(courierByLand2);
                        System.out.printf("You Bill is %s", courierByLand2.getFoodFee());
                       break;
                    case 3:

                        System.out.println("So You Want to Deliver General Items");

                        System.out.println("Enter Your Good Name");
                        name = scan.nextLine();
                        ValidateName(name);

                        System.out.println("Enter you Age");
                        age = Integer.valueOf(scan.nextLine());
                        ValidateAge(age);

                        System.out.println("Enter Package Name");
                        packagename = scan.nextLine();

                        System.out.println("Enter Pickup City");
                        pickaddress = scan.nextLine();

                        System.out.println("Enter Delivery City");
                        deliveryaddress = scan.nextLine();

                        CourierByLand courierByLand3 = new CourierByLand(name,age,packagename,pickaddress,deliveryaddress);
                        ShowResult(courierByLand3);
                        System.out.printf("You Bill is %s", courierByLand3.getGeneralItemsFee());
                        break;
                    case 4:
                        System.out.println("So You Want to Deliver Others Items");

                        System.out.println("Enter Your Good Name");
                        name = scan.nextLine();
                        ValidateName(name);

                        System.out.println("Enter you Age");
                        age = Integer.valueOf(scan.nextLine());
                        ValidateAge(age);

                        System.out.println("Enter Package Name");
                        packagename = scan.nextLine();

                        System.out.println("Enter Pickup City");
                        pickaddress = scan.nextLine();

                        System.out.println("Enter Delivery City");
                        deliveryaddress = scan.nextLine();

                        CourierByLand courierByLand4 = new CourierByLand(name,age,packagename,pickaddress,deliveryaddress);
                        ShowResult(courierByLand4);
                        System.out.printf("You Bill is %s", courierByLand4.getOtherItemFee());
                        break;


                }

                break;
            case 2:
                System.out.println("You've Selected the option to go by Sea \n");
                int op3;
                System.out.println("Category \n Select Option \n 01) Electronics \n 02) Food \n 03) General Items \n 04) Other");
                op3 = Integer.valueOf(scan.nextLine());
                switch (op3){
                    case 1:
                        System.out.println("So You Want to Deliver Electronics Items");

                        System.out.println("Enter Your Good Name");
                        name = scan.nextLine();
                        ValidateName(name);

                        System.out.println("Enter you Age");
                        age = Integer.valueOf(scan.nextLine());
                        ValidateAge(age);

                        System.out.println("Enter Package Name");
                        packagename = scan.nextLine();

                        System.out.println("Enter Pickup City");
                        pickaddress = scan.nextLine();

                        System.out.println("Enter Delivery City");
                        deliveryaddress = scan.nextLine();

                        CourierBySea courierBySea = new CourierBySea(name,age,packagename,pickaddress,deliveryaddress);
                        ShowResult(courierBySea);
                        System.out.printf("You Bill is %s", courierBySea.getElectronicsFee());
                        break;
                    case 2:
                        System.out.println("So You Want to Deliver Food Items");

                        System.out.println("Enter Your Good Name");
                        name = scan.nextLine();
                        ValidateName(name);

                        System.out.println("Enter you Age");
                        age = Integer.valueOf(scan.nextLine());
                        ValidateAge(age);

                        System.out.println("Enter Package Name");
                        packagename = scan.nextLine();

                        System.out.println("Enter Pickup City");
                        pickaddress = scan.nextLine();

                        System.out.println("Enter Delivery City");
                        deliveryaddress = scan.nextLine();

                        CourierBySea courierBySea2 = new CourierBySea(name,age,packagename,pickaddress,deliveryaddress);
                        ShowResult(courierBySea2);
                        System.out.printf("You Bill is %s", courierBySea2.getFoodFee());
                        break;
                    case 3:

                        System.out.println("So You Want to Deliver General Items");

                        System.out.println("Enter Your Good Name");
                        name = scan.nextLine();
                        ValidateName(name);

                        System.out.println("Enter you Age");
                        age = Integer.valueOf(scan.nextLine());
                        ValidateAge(age);

                        System.out.println("Enter Package Name");
                        packagename = scan.nextLine();

                        System.out.println("Enter Pickup City");
                        pickaddress = scan.nextLine();

                        System.out.println("Enter Delivery City");
                        deliveryaddress = scan.nextLine();

                        CourierBySea courierBySea3 = new CourierBySea(name,age,packagename,pickaddress,deliveryaddress);
                        ShowResult(courierBySea3);
                        System.out.printf("You Bill is %s", courierBySea3.getGeneralItemsFee());
                        break;
                    case 4:
                        System.out.println("So You Want to Deliver Others Items");

                        System.out.println("Enter Your Good Name");
                        name = scan.nextLine();
                        ValidateName(name);

                        System.out.println("Enter you Age");
                        age = Integer.valueOf(scan.nextLine());
                        ValidateAge(age);

                        System.out.println("Enter Package Name");
                        packagename = scan.nextLine();

                        System.out.println("Enter Pickup City");
                        pickaddress = scan.nextLine();

                        System.out.println("Enter Delivery City");
                        deliveryaddress = scan.nextLine();

                        CourierBySea courierBySea4 = new CourierBySea(name,age,packagename,pickaddress,deliveryaddress);
                        ShowResult(courierBySea4);
                        System.out.printf("You Bill is %s", courierBySea4.getOtherItemFee());
                        break;


                }
                break;
        }

    }
    catch (Exception e){
        System.out.println(e.getMessage());
    }

}while(flag == 1);
  //      System.out.println("Do you want to set another order? (1 for yes, 0 for no)");
   //     flag = Integer.valueOf(scan.nextLine());
}

    public static void ShowResult(Courier result){
        System.out.printf("\n ****** Congratulation ********* \n Your Order has been Confirmed \n Order Information \n Mr/Mrs %s has orderd %s today %s service from %s to %s \n ",result.getName(),result.getPackageName(),result.getDeliverThrough(),result.getPickupAddress(),result.getDeliverAddress());

    }

    public static void ValidateOption (int op)throws Exception{
        if(!(op>=1 && op<=2)){
      throw new Exception("Invalid Option");
        }
    }

    public static void ValidateName(String name)throws Exception{
        if(name.length() <3){
            throw new Exception("Name length should must be 3");
        }
    }

    public static void ValidateAge(int age)throws Exception{
        if(!(age>=1 && age<=99)){
            throw new Exception("This Service isn't for 100++");
        }
    }


}
