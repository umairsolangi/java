// Part time employee gets 50% less payment than full time one.

public class PartTime extends Employee{

    public PartTime(String name, int age, String designation, int birthDate) {
        super(name, age, designation, birthDate);
    }

    public void calculateAndShowAnnualPayment() {
        System.out.printf("Your annual pay is %d pkr.\n", monthlyPayment);
    }
}
