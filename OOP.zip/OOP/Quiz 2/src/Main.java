/* Inheritance in this program is multi level, because Person can be any Student, Employee or Customer.
 * Student can be graduate or undergraduate.
 * Employee can be part time or full time.
 * Customer can be walking or regular*/

/* The reason why Person, Student, Employee and Customer classes are abstract because it there are specific person, student, employees and customers. */

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        // Where all students, customers and Employee will be stored.
        Person[] persons = new Person[50];

        int noOfPersons;
        System.out.println("How many persons are there? ");
        noOfPersons = Integer.valueOf(scan.nextLine());

        int op, op2, age, birthDate, flag;
        String name, designation;

        // Creating person object where all types of person can be stored.
        // Made the person object point to nothing to resolve an error.
        Person per = null;
        for(int i = 0; i<noOfPersons; i++) {



            flag = 0;
            do {

                try {
                    System.out.println("Are you a student, an Employee or a Customer? (1 for Student, 2 for Employee, 3 for Customer)");
                    op = Integer.valueOf(scan.nextLine());
                    validOption3(op);
                    if (op == 1) {


                        System.out.println("Are you a graduate or undergraduate student? (1 for graduate, 2 for undergraduate ");
                        op2 = Integer.valueOf(scan.nextLine());
                        validOption2(op2);
                        if (op2 == 1) {
                            System.out.printf("Enter name of Student %d\n", i + 1);
                            name = scan.nextLine();
                            System.out.printf("Enter age of Student %d\n", i + 1);
                            age = Integer.valueOf(scan.nextLine());
                            verifyGraduateAge(age);
                            System.out.printf("Enter birthDate of Student: ");
                            birthDate = Integer.valueOf(scan.nextLine());
                            per = new GradguateStd(name, age, birthDate);
                        }
                        // Else student will be undergraduate
                        else {
                            System.out.printf("Enter name of Student %d\n", i + 1);
                            name = scan.nextLine();
                            System.out.printf("Enter age of Student %d\n", i + 1);
                            age = Integer.valueOf(scan.nextLine());
                            System.out.printf("Enter birthDate of Student: ");
                            birthDate = Integer.valueOf(scan.nextLine());
                            per = new UnderGradStd(name, age, birthDate);
                        }
                    }
                    // Else the person is an Employee
                    else if (op == 2) {
                        System.out.println("Are you a part time or fulltime employee? (1 for partTime, 2 for fullTime)");
                        op2 = Integer.valueOf(scan.nextLine());
                        validOption2(op2);
                        if (op2 == 1) {
                            System.out.printf("Enter name of PartTime Employee %d\n", i + 1);
                            name = scan.nextLine();
                            System.out.printf("Enter age of PartTime Employee %d\n", i + 1);
                            age = Integer.valueOf(scan.nextLine());
                            System.out.printf("Enter designation of parttime employee: %d\n", i + 1);
                            designation = scan.nextLine();
                            System.out.println("Enter birthDate of employee: ");
                            birthDate = Integer.valueOf(scan.nextLine());
                            per = new PartTime(name, age, designation, birthDate);
                        }
                        // Else student will be undergraduate
                        else {
                            System.out.printf("Enter name of Full time Employee %d\n", i + 1);
                            name = scan.nextLine();
                            System.out.printf("Enter age of FullTime Employee %d\n", i + 1);
                            age = Integer.valueOf(scan.nextLine());
                            System.out.printf("Enter designation of Full time employee: %d\n", i + 1);
                            designation = scan.nextLine();
                            System.out.println("Enter birthDate of employee: ");
                            birthDate = Integer.valueOf(scan.nextLine());
                            per = new FullTime(name, age, designation, birthDate);
                        }
                    } else {
                        System.out.println("Are you a walking or regular customer? (1 for walking, 2 for regular)");
                        op2 = Integer.valueOf(scan.nextLine());
                        validOption2(op2);

                        if (op2 == 1) {
                            System.out.printf("Enter name of walking customer %d\n", i + 1);
                            name = scan.nextLine();
                            System.out.printf("Enter age of walking customer %d\n", i + 1);
                            age = Integer.valueOf(scan.nextLine());
                            System.out.println("Enter birthDate of walking customer: ");
                            birthDate = Integer.valueOf(scan.nextLine());
                            per = new Walken(name, age, birthDate);
                        } else {
                            System.out.printf("Enter name of regular customer %d\n", i + 1);
                            name = scan.nextLine();
                            System.out.printf("Enter age of regular customer %d\n", i + 1);
                            age = Integer.valueOf(scan.nextLine());
                            System.out.println("Enter birthDate of regular customer: ");
                            birthDate = Integer.valueOf(scan.nextLine());
                            per = new Regular(name, age, birthDate);
                        }

                        // When last statement is reached than there is no exception.
                        flag = 1;
                    }
                } catch(Exception e) {
                    System.out.println(e.getMessage());
                }
            } while(flag == 0);
            // Now that person will be added to the array.
            persons[i] = per;
        }


    }

    public static void verifyGraduateAge(int age) throws Exception {
        if (!(age>25)) {
            throw new Exception("Graduate age should be greater than 25");
        }
    }

    public static void verifyUndergraduateAge(int age) throws Exception {
        if(!(age>=20 && age <=25)) {
            throw new Exception("Undergraduate age should be  20 - 25");
        }
    }

    public static void validOption3(int op) throws Exception {
        if(!(op == 1 || op == 2 || op == 3)) {
            throw new Exception("Invalid option, try again");
        }
    }

    public static void validOption2(int op) throws Exception {
        if(!(op == 1 || op == 2 )) {
            throw new Exception("Invalid option, try again");
        }
    }
}
