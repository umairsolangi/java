// Full time employee earns 50% more than part time one.

public class FullTime extends Employee {

    public FullTime(String name, int age, String designation, int birthDate) {
        super(name, age, designation, birthDate);
    }

    public void calculateAndShowAnnualPayment() {
        double ExtraHours = monthlyPayment * 0.5;
        ExtraHours += monthlyPayment;
        System.out.printf("Your annual pay is %d pkr.\n", ExtraHours);
    }
}
