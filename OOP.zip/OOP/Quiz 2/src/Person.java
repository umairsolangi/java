public abstract class Person {
    protected String name;
    protected int age;
    protected int birthDate;

    public Person(String name, int age, int birthDate) {
        this.name = name;
        this.age = age;
        this.birthDate = birthDate;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    public int getBirthDate() {
        return birthDate;
    }
}
