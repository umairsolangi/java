public class Shoes extends Company{
    public Shoes(String category, String company, String model, int price, int id){
        super(category,company,model,price, id);

    }
}
