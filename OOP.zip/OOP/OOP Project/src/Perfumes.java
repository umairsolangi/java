import java.util.ArrayList;

public class Perfumes extends Company {

    //private ArrayList<String> perfumes;

    public Perfumes(String category, String company, String model, int price, int id) {
        super(category, company, model, price, id);

    }
}
