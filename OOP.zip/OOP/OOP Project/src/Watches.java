import java.util.ArrayList;

public class Watches extends Company {

    //private ArrayList<String> watches;

    public Watches(String category, String company, String model, int price, int id) {
        super(category, company, model, price, id);
    }
}
