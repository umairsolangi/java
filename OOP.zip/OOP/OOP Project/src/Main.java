import javax.xml.crypto.Data;
import java.util.Scanner;

// If user wants to add new category, for example shoes than use product class will have its feature.

public class Main {
    public static void main(String[] args) {
        DataStored dataStored;
        dataStored = addData();

        int totalBill = showMenu(dataStored);

        System.out.printf("Your total bill is: %d\nThanks for shopping!", totalBill);
        //dataStored = takeInput();
        //showData(dataStored);
        //showAllData(dataStored);
    }

    public static int showMenu(DataStored data) {

        int op3 = 0;
        int totalBill=0;

        do {
            try {
                System.out.println("\t\t________ITEMS IN OUR ONLINE CART SHOPPING________\n\n");
                System.out.println("Enter your option to view items of categories: ");
                System.out.println("1) Watches");
                System.out.println("2) Perfumes");
                System.out.println("3) Shoes");
                System.out.println("4) Mobile Phones");
                //System.out.println("5) Head Phones");
                //System.out.println("6) Other Products"); // This one doesn't work.
                int op;
                Scanner scan = new Scanner(System.in);
                op = Integer.valueOf(scan.nextLine());
                verifyOption(op);

                // Also need to add functionality so that user can add item in its cart.
                // Maybe I should add id of each item and than look it up to add its price.
                int id;
                int indexOfItem;
                int op2;
                op3 = 1;
                //totalBill = 0;
                switch (op) {
                    case 1:
                        showWatchData(data);
                        System.out.println("\nSelect the item id, you want to purchase: ");
                        id = Integer.valueOf(scan.nextLine());
                        verifyProductId(id);
                        // Now we search id against the list and add item and price to cart.
                        indexOfItem = searchProduct(id, "watches", data);
                        Watches watch = data.watches.get(indexOfItem);
                        System.out.printf("Do you want to purchase %s of %d rupees?(1 for yes, 0 for no)\n", watch.model, watch.price);
                        op2 = Integer.valueOf(scan.nextLine());
                        if (op2 == 1) {
                            System.out.println("Item added on cart!");
                            totalBill += watch.price;
                            System.out.printf("Your bill is: %d!\n", totalBill);
                        } else {
                            System.out.println("Order cancelled!");
                        }
                        break;
                    case 2:
                        showPerfumeData(data);
                        System.out.println("\nSelect the item id, you want to purchase: ");
                        id = Integer.valueOf(scan.nextLine());
                        verifyProductId(id);
                        // Now we search id against the list and add item and price to cart.
                        indexOfItem = searchProduct(id, "perfumes", data);
                        Perfumes perfume = data.perfumes.get(indexOfItem);
                        System.out.printf("Do you want to purchase %s of %d rupees?(1 for yes, 0 for no)\n", perfume.model, perfume.price);
                        op2 = Integer.valueOf(scan.nextLine());
                        if (op2 == 1) {
                            System.out.println("Item added on cart!");
                            totalBill += perfume.price;
                            System.out.printf("Your bill is: %d!\n", totalBill);
                        } else {
                            System.out.println("Order cancelled!");
                        }
                        break;
                    case 3:
                        showShoes(data);
                        System.out.println("\nSelect the item id, you want to purchase: ");
                        id = Integer.valueOf(scan.nextLine());
                        verifyProductId(id);
                        // Now we search id against the list and add item and price to cart.
                        indexOfItem = searchProduct(id, "shoes", data);
                        Shoes shoe = data.shoes.get(indexOfItem);
                        System.out.printf("Do you want to purchase %s of %d rupees?(1 for yes, 0 for no)\n", shoe.model, shoe.price);
                        op2 = Integer.valueOf(scan.nextLine());
                        if (op2 == 1) {
                            System.out.println("Item added on cart!");
                            totalBill += shoe.price;
                            System.out.printf("Your bill is: %d!\n", totalBill);
                        } else {
                            System.out.println("Order cancelled!");
                        }
                        break;
                    case 4:
                        System.out.println("\nSelect the item id, you want to purchase: ");
                        showMobilePhones(data);
                        id = Integer.valueOf(scan.nextLine());
                        verifyProductId(id);
                        // Now we search id against the list and add item and price to cart.
                        indexOfItem = searchProduct(id, "mobilephones", data);
                        MobilePhones mobilePhone = data.mobilePhones.get(indexOfItem);
                        System.out.printf("Do you want to purchase %s of %d rupees?(1 for yes, 0 for no)\n", mobilePhone.model, mobilePhone.price);
                        op2 = Integer.valueOf(scan.nextLine());
                        if (op2 == 1) {
                            System.out.println("Item added on cart!");
                            totalBill += mobilePhone.price;
                            System.out.printf("Your bill is: %d!\n", totalBill);
                        } else {
                            System.out.println("Order cancelled!");
                        }

                        break;


                    case 5:
                        System.out.println("\nSelect the item id, you want to purchase: ");
                        showOtherData(data);
                        id = Integer.valueOf(scan.nextLine());
                        verifyProductId(id);
                        // Now we search id against the list and add item and price to cart.
                        indexOfItem = searchProduct(id, "perfumes", data);
                        Product product = data.otherProducts.get(indexOfItem);
                        System.out.printf("Do you want to purchase %s of %d rupees?(1 for yes, 0 for no)\n", product.model, product.price);
                        op2 = Integer.valueOf(scan.nextLine());
                        if (op2 == 1) {
                            System.out.println("Item added on cart!");
                            totalBill += product.price;
                            System.out.printf("Your bill is: %d!\n", totalBill);
                        } else {
                            System.out.println("Order cancelled!");
                        }
                        break;

                }

                System.out.println("Do you want to buy any other item? (1 for yes, 0 for no)");
                op3 = Integer.valueOf(scan.nextLine());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        } while (op3 == 1);

        return totalBill;
    }

    public static void verifyOption(int op) throws Exception {
        if(!(op==1 || op ==2 || op ==3 || op ==4)) {
            throw new Exception("Invalid Option");
        }
    }

    public static void verifyProductId(int op) throws Exception {
        if(!(op>=10 && op <=20)) {
            throw new Exception("Invalid Option");
        }
    }

    // Function to search product using its id.
    // Trying to return index instead of company to solve return error issue.
    public static int searchProduct(int ProductId, String productType, DataStored data) {
        if(productType.toLowerCase().equals("watches")) {
            Watches watch;
            for(int i=0; i<data.watches.size(); i++) {
                watch = data.watches.get(i);
                if(watch.id == ProductId) {
                    //return watch;
                    return i;
                }
            }
        }
        else if(productType.toLowerCase().equals("perfumes")) {
            Perfumes perfume;
            for(int i=0; i<data.perfumes.size(); i++) {
                perfume = data.perfumes.get(i);
                if(perfume.id == ProductId) {
                    //return perfume;
                    return i;
                }
            }
        }
        else if(productType.toLowerCase().equals("shoes")) {
            Shoes shoe;
            for(int i=0; i<data.shoes.size(); i++) {
                shoe = data.shoes.get(i);
                if(shoe.id == ProductId) {
                    //return shoe;
                    return i;
                }
            }
        }
        else if(productType.toLowerCase().equals("mobilephones")) {
            MobilePhones mphone;
            for(int i=0; i<data.mobilePhones.size(); i++) {
                mphone = data.mobilePhones.get(i);
                if(mphone.id==ProductId) {
                    //return mphone;
                    return i;
                }
            }
        }
        // Last else for other products
        else {
            Product product;
            for(int i = 0; i<data.otherProducts.size(); i++) {
                product = data.otherProducts.get(i);
                if(product.id == ProductId) {
                    //return product;
                    return i;
                }
            }
        }
        // if nothing is found than -1 is returned.
        return -1;
    }

    // Need to make a function to manually add data to show the user what it has in stock.
    public static DataStored addData() {
        // Need to add watches.
        DataStored data= new DataStored();
        Watches obj = new Watches("Watches", "Rolex", "E99", 23000, 10);
        data.addWatch(obj);
        Watches obj1 = new Watches("Watches", "Quartz", "E77", 25000,11);
        data.addWatch(obj1);
        Watches obj2 = new Watches("Watches", "Citizen", "E84", 20000,12);
        data.addWatch(obj2);

        // Now adding perfumes.

        Perfumes obj3 = new Perfumes("Perfumes", "Fogg", "U44", 999,13);
        data.addPerfume(obj3);
        Perfumes obj4 = new Perfumes("Perfumes", "Bold", "E999", 1800,14);
        data.addPerfume(obj4);
        Perfumes obj5 = new Perfumes("Perfumes", "Calvin Klein", "Y244", 2900,14);
        data.addPerfume(obj5);

        // Now adding shoes

        Shoes obj6 = new Shoes("Shoes","Nike","Air Jordan",16900,15);
        data.addShoes(obj6);
        Shoes obj7 = new Shoes("Shoes", "Adidas","Superstar Black Edition",9800,16);
        data.addShoes(obj7);
        Shoes obj8 = new Shoes("Shoes","Vans","Checkerboard Classic",12800,17);
        data.addShoes(obj8);

        // Now adding MobilePhones

        MobilePhones obj9 = new MobilePhones("MobilePhone","Apple","iPhone 13 Pro Max ",269000,18);
        data.addMobilePhones(obj9);
        MobilePhones obj10 = new MobilePhones("MobilePhone", "Samsung","S22 Ultra",209800,19);
        data.addMobilePhones(obj10);
        MobilePhones obj11 = new MobilePhones("MobilePhone","Huawei","Mate 20 Pro",228000,20);
        data.addMobilePhones(obj11);

        //Now adding head phones
        /*
        Headphones obj12 = new Headphones("Head phones","Corsair","HS60 Pro",11900,21);
        data.addHeadphones(obj12);
        Headphones obj13 = new Headphones("Head phones","Apple","AirPods Pro Max",149000,22);
        data.addHeadphones(obj13);
        Headphones obj14 = new Headphones("Head phones","Turtle Beach","Light Mic",12900,23);
        data.addHeadphones(obj14);
        */

        return data;
    }


    public static DataStored takeInput() {
        DataStored data = new DataStored();
        Scanner scan = new Scanner(System.in);

        // Need to apply dynamic polyomorphism to add products. Ask if he prodcut is watch or perfume.
        int op = 1;
        do {

            System.out.println("Enter category of item: ");
            String category = scan.nextLine();
            System.out.println("Enter company of item: ");
            String company = scan.nextLine();
            System.out.println("Enter model of item: ");
            String model = scan.nextLine();
            System.out.println("Enter price of item: ");
            int price = Integer.valueOf(scan.nextLine());
            System.out.println("Enter Id of item: ");
            int id = Integer.valueOf(scan.nextLine());

            if (category.toLowerCase().equals("watches")) {
                // Am changing Polymorphic variable Company to Watches so that data can be added correctly.
                Watches obj = new Watches(category, company, model, price,id);
                data.addWatch(obj);
            } else if (category.toLowerCase().equals("perfumes")) {
                // Same happening as above.
                Perfumes obj = new Perfumes(category, company, model, price,id);
                data.addPerfume(obj);
            }
            else if (category.toLowerCase().equals("shoes")){
                Shoes obj = new Shoes(category,company,model,price,id);
                data.addShoes(obj);
            }
            else if(category.toLowerCase().equals("mobile-phones")){
                MobilePhones obj = new MobilePhones(category,company,model,price,id);
                data.addMobilePhones(obj);
            }
            /*else if(category.toLowerCase().equals("head phones")){
                Headphones obj = new Headphones(category,company,model,price,id);
                data.addHeadphones(obj);
            } */
            // When category is other than the specified ones.
            else {
                Product obj = new Product(category, company, model, price,id);
                data.addOtherProduct(obj);
            }

            System.out.println("Do you want to add an item in the list again? (1 for yes/ 0 for no)");
            op = Integer.valueOf(scan.nextLine());
        } while(op == 1);

        return data;
    }

    public static void showWatchData(DataStored data) {
        System.out.println("________WATCHES_________");
        // Will be returning watch and than access its properties.
        Watches watch;
        for(int i = 0; i<data.watches.size(); i++) {
            watch = data.watches.get(i);
            //System.out.printf("Company: %s\nModel %s\nPrice: %d\n\n", watch.company, watch.model, watch.price);
            System.out.printf("(Order ID) %d\nCompany: %s\nModel %s\nPrice: %d\n\n",watch.id, watch.company, watch.model, watch.price);
        }
    }

    public static void showPerfumeData(DataStored data) {
        System.out.println("_______PERFUMES_________");

        Perfumes perfume;
        for(int i = 0; i<data.perfumes.size(); i++) {
            perfume = data.perfumes.get(i);
            System.out.printf("(Order ID) %d\nCompany: %s\nModel %s\nPrice: %d\n\n",perfume.id, perfume.company, perfume.model, perfume.price);
        }
    }
    public static void showShoes(DataStored data){
        System.out.println("_______Shoes_______");
        Shoes shoes;
        for(int i = 0; i<data.shoes.size(); i++){
            shoes = data.shoes.get(i);
            System.out.printf("(Order ID) %d\nCompany: %s\nModel %s\nPrice: %d\n\n", shoes.id,shoes.company,shoes.model,shoes.price);
        }
    }
    public static void showMobilePhones(DataStored data){
        System.out.println("_______MobilePhones_______");
        MobilePhones mobilePhones;
        for(int i = 0; i<data.mobilePhones.size(); i++){
            mobilePhones = data.mobilePhones.get(i);
            System.out.printf("(Order ID) %d\nCompany: %s\nModel %s\nPrice: %d\n\n",mobilePhones.id,mobilePhones.company,mobilePhones.model,mobilePhones.price);
        }

    }
    /*public static void showHeadPhones(DataStored data){
        System.out.println("_______HeadPhones_______");
        Headphones headphones;
        for(int i = 0; i<data.headphones.size(); i++){
            headphones = data.headphones.get(i);
            System.out.printf("(Order ID) %d\nCompany: %s\nModel %s\nPrice: %d\n\n",headphones.id,headphones.company,headphones.model,headphones.price);
        }
    } */

    public static void showOtherData(DataStored data) {
        System.out.println("__________OTHER ITEMS___________");

        Product product;
        for(int i=0; i<data.otherProducts.size(); i++) {
            product = data.otherProducts.get(i);
            System.out.printf("(Order ID) %d\nCompany: %s\nModel %s\nPrice: %d\n\n",product.id, product.company, product.model, product.price);
        }
    }

    public static void showAllData(DataStored data) {
        System.out.println("________WATCHES_________");
        // Will be returning watch and than access its properties.
        Watches watch;
        for(int i = 0; i<data.watches.size(); i++) {
            watch = data.watches.get(i);
            System.out.printf("(Order ID) %d\nCompany: %s\nModel %s\nPrice: %d\n\n",watch.id, watch.company, watch.model, watch.price);
        }

        System.out.println("_______PERFUMES_________");

        Perfumes perfume;
        for(int i = 0; i<data.perfumes.size(); i++) {
            perfume = data.perfumes.get(i);
            System.out.printf("(Order ID) %d\nCompany: %s\nModel %s\nPrice: %d\n\n",perfume.id, perfume.company, perfume.model, perfume.price);
        }
        System.out.println("_______Shoes_______");
        Shoes shoes;
        for(int i = 0; i<data.shoes.size(); i++){
            shoes = data.shoes.get(i);
            System.out.printf("(Order ID) %d\nCompany: %s\nModel %s\nPrice: %d\n\n", shoes.id,shoes.company,shoes.model,shoes.price);
        }
        System.out.println("_______MobilePhones_______");
        MobilePhones mobilePhones;
        for(int i = 0; i<data.mobilePhones.size(); i++){
            mobilePhones = data.mobilePhones.get(i);
            System.out.printf("(Order ID) %d\nCompany: %s\nModel %s\nPrice: %d\n\n",mobilePhones.id,mobilePhones.company,mobilePhones.model,mobilePhones.price);
        }
        /*System.out.println("_______HeadPhones_______");
        Headphones headphones;
        for(int i = 0; i<data.headphones.size(); i++){
            headphones = data.headphones.get(i);
            System.out.printf("(Order ID %d\nCompany: %s\nModel %s\nPrice: %d\n\n",headphones.id,headphones.company,headphones.model,headphones);
        } */

        System.out.println("__________OTHER ITEMS___________");

        Product product;
        for(int i=0; i<data.otherProducts.size(); i++) {
            product = data.otherProducts.get(i);
            System.out.printf("(Order ID) %d\nCompany: %s\nModel %s\nPrice: %d\n\n",product.id, product.company, product.model, product.price);
        }

    }
}
